import React from "react";
import { Container, Row, Col,Form,Button} from 'react-bootstrap';
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import UserService from './redux/services/Userservice';

function Settings() {
  const dispatch = useDispatch();
  const shopInfo = useSelector((state) => state.usersData);

    const websiteurlText = "https://"+ new URL(location).searchParams.get("shop");
    const [primarycolor, setprimarycolor] = useState(shopInfo.primaryColor);
    const [secondarycolor, setsecondarycolor] = useState(shopInfo.secondaryColor);
    const [backgroundcolor, setbackgroundcolor] = useState(shopInfo.backgroundColor);
    const [tertiarycolor, settertiarycolor ]= useState(shopInfo.tertiaryColor);
    const [rewardcolor, setrewardcolor]= useState(shopInfo.rewardpointColor);
    const [positionwigets, setpositionwigets]= useState(shopInfo.widgetposition);
    const [websiteurl, setwebsiteurl]= useState(websiteurlText);
    const [widgetsbuttontext, setwidgetsbuttontext]= useState(shopInfo.widgetbutttontext);
    const [boxheading1, setboxheading1]= useState(shopInfo.discountbuttontext);
    const [box1buttontext, setbox1buttontext]= useState("chat now!");
    const [boxheading2, setboxheading2]= useState("check point");
    const [boxheading3, setboxheading3]= useState("Redeem points");
    const [box2description, setbox2description]= useState("Enter your phone number to know how many reward points you have won with your phone number");
    const [box3descriptionreward, setbox3descriptionreward]= useState("Nice you can generate a coupon code using available points");
    const [box3descriptionrewardnot, setbox3descriptionrewardnot]= useState("Sorry!! you dont have any reward point");
    const [box_4_description, setbox_4_description]= useState("Congratulation you can now use above coupon code to get excting offers.");

  const primaryColorhandlechange = (event) => { 
    setprimarycolor(event.target.value);
    UserService.loadprimarycolor(dispatch,event.target.value);   
     
   };
   const secondaryColorhandlechange = (event) => { 
    setsecondarycolor(event.target.value);
    UserService.loadsecondarycolor(dispatch,event.target.value);  
     
   };
   const backgroundcolorhandlechange = (event) => { 
    setbackgroundcolor(event.target.value);
    UserService.loadbackgroundcolor(dispatch,event.target.value);  
    
   };
   const tertiaryhandlechange = (event) => { 
    settertiarycolor(event.target.value);
    UserService.loadtertiaryColor(dispatch,event.target.value);   
     
   };
   const rewardcolorhandlechange = (event) => { 
    setrewardcolor(event.target.value); 
    UserService.loadrewardcolor(dispatch,event.target.value); 
   };

   const positionwigetshandlechange = (event) => { 
    setpositionwigets(event.target.value)  
    UserService.loadwidgetposition(dispatch,event.target.value); 
   };
   
   const widgetsbuttonhandlechange = (event) => { 
    setwidgetsbuttontext(event.target.value)  
    UserService.loadwidgetbuttontext(dispatch,event.target.value); 
   };

   const boxheading1handlechange = (event) => { 
    setboxheading1(event.target.value)  
    UserService.loaddiscountbuttontext(dispatch,event.target.value);
     
   };
   const box1buttontexthandlechange = (event) => { 
    setbox1buttontext(event.target.value)  
     
   };

   
const boxheading2handlechange = (event) => { 
  setboxheading2(event.target.value)  
};




const boxheading3handlechange = (event) => { 
  setboxheading3(event.target.value)  
};

const box2descriptionhandlechange = (event) => { 
  setbox2description(event.target.value)  
};

const box3descriptionrewardhandlechange = (event) => { 
  setbox3descriptionreward(event.target.value)  
};


const box3descriptionrewardnothandlechange = (event) => { 
  setbox3descriptionrewardnot(event.target.value)  
};

const box4descriptionhandlechange = (event) => { 
  setbox_4_description(event.target.value)  
};


  return (
    <>
      <Row>
        <Row className="align-items-start mb-2">
          <Col sm={6}>
            <p>Primary Color:</p>
          </Col>

          <Col sm={6} className="d-flex align-items-center">
            <input
              type="color"
              id="primarycolor"
              value={primarycolor}
              onChange={primaryColorhandlechange}
              className="input_color"
            />
            <label htmlFor="primarycolor">{primarycolor}</label>
          </Col>
        </Row>

        <Row className="align-items-start mb-2">
          <Col sm={6}>
            <p>Seconadary color:</p>
          </Col>

          <Col sm={6} className="d-flex align-items-center mb-2">
            <input
              type="color"
              id="secondarycolor"
              value={secondarycolor}
              onChange={secondaryColorhandlechange}
              className="input_color"
            />
            <label htmlFor="secondarycolor">{secondarycolor}</label>
          </Col>
        </Row>

        <Row className="align-items-start mb-2">
          <Col sm={6}>
            <p>Background color:</p>
          </Col>

          <Col sm={6} className="d-flex align-items-center">
            <input
              type="color"
              id="backgroundcolor"
              value={backgroundcolor}
              onChange={backgroundcolorhandlechange}
              className="input_color"
            />
            <label htmlFor="backgroundcolor">{backgroundcolor}</label>
          </Col>
        </Row>
        <Row className="align-items-start mb-2">
          <Col sm={6}>
            <p>Tertiary color:</p>
          </Col>

          <Col sm={6} className="d-flex align-items-center">
            <input
              type="color"
              id="textcolor"
              value={tertiarycolor}
              onChange={tertiaryhandlechange}
              className="input_color"
            />
            <label htmlFor="textcolor">{tertiarycolor}</label>
          </Col>
        </Row>
        <Row className="align-items-start mb-2">
          <Col sm={6}>
            <p>Reward point color:</p>
          </Col>

          <Col sm={6} className="d-flex align-items-center">
            <input
              type="color"
              id="rewardcolor"
              value={rewardcolor}
              onChange={rewardcolorhandlechange}
              className="input_color"
            />
            <label htmlFor="rewardcolor">{rewardcolor}</label>
          </Col>
        </Row>
        <div className="posiotion_wiget_app mb-2">
          <label htmlFor="positionwiget">Position</label>
          <Form.Select
            aria-label="Default select example"
            id="positionwiget"
            onChange={positionwigetshandlechange}
            defaultValue={positionwigets}
          >
            <option value="left">left</option>
            <option value="right">right</option>
          </Form.Select>
        </div>

        <div className="websiteurl mb-2">
          <Form.Label htmlFor="websiteurl">Website Url</Form.Label>
          <Form.Control type="text" id="websiteurl" defaultValue={websiteurl} />
        </div>
        <div className="clientname">
          <Form.Label htmlFor="clientname">Client Name</Form.Label>
          <Form.Control
            type="text"
            id="clientname"
            defaultValue="Client Name"
          />
        </div>
        <div className="wigets_button_text mb-2">
          <Form.Label htmlFor="wigets_button_text">
            Widget button text
          </Form.Label>
          <Form.Control
            type="text"
            id="wigets_button_text"
            defaultValue={widgetsbuttontext}
            onChange={widgetsbuttonhandlechange}
          />
        </div>
        <div className="box_heading_1 mb-2">
          <Form.Label htmlFor="box_heading_1">Box heading 1 text(Discount code button)</Form.Label>
          <Form.Control
            type="text"
            id="wigets_button_text"
            defaultValue={boxheading1}
            onChange={boxheading1handlechange}
          />
        </div>
        <div className="box_1_button_text mb-2">
          <Form.Label htmlFor="box_1_button_text">Box button text</Form.Label>
          <Form.Control
            type="text"
            id="box_1_button_text"
            defaultValue={box1buttontext}
            onChange={box1buttontexthandlechange}
          />
        </div>
        <div className="box_2_heading mb-2">
          <Form.Label htmlFor="box_2_heading">Box 2 heading</Form.Label>
          <Form.Control
            type="text"
            id="box_2_heading"
            defaultValue={boxheading2}
            onChange={boxheading2handlechange}
          />
        </div>
        <div className="box_3_heading mb-2">
          <Form.Label htmlFor="box_3_heading">Box 3 heading</Form.Label>
          <Form.Control
            type="text"
            id="box_3_heading"
            defaultValue={boxheading3}
            onChange={boxheading3handlechange}
          />
        </div>

        <div className="box_2_description mb-2">
          <Form.Label htmlFor="box_2_description">Box 2 description</Form.Label>
          <Form.Control
            as="textarea"
            defaultValue={box2description}
            placeholder={box2description}
            style={{ height: "100px" }}
            onChange={box2descriptionhandlechange}
            id="box_2_description"
          />
        </div>

        <div className="box_3_description_reward_point mb-2">
          <Form.Label htmlFor="box_3_description_reward_point">
            Box 3 description
          </Form.Label>
          <Form.Control
            as="textarea"
            defaultValue={box3descriptionreward}
            placeholder={box3descriptionreward}
            style={{ height: "100px" }}
            onChange={box3descriptionrewardhandlechange}
            id="box_3_description_reward_point"
          />
        </div>

        <div className="box_3_description_reward_point_not_available mb-2">
          <Form.Label htmlFor="box_3_description_reward_point_not_available">
            Box 3 description(Reward point not available)
          </Form.Label>
          <Form.Control
            as="textarea"
            defaultValue={box3descriptionrewardnot}
            placeholder={box3descriptionrewardnot}
            style={{ height: "100px" }}
            onChange={box3descriptionrewardnothandlechange}
            id="box_3_description_reward_point_not_available"
          />
        </div>

        <div className="box_4_description mb-2">
          <Form.Label htmlFor="box_4_description">Box 4 description</Form.Label>
          <Form.Control
            as="textarea"
            defaultValue={box_4_description}
            placeholder={box_4_description}
            style={{ height: "100px" }}
            onChange={box4descriptionhandlechange}
            id="box_3_description_reward_point_not_available"
          />
        </div>

        <Button variant="primary" id="savesettings" className="mb-4 mt-3">
          <span className="save_icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className="bi bi-download"
              viewBox="0 0 16 16"
            >
              <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
              <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
            </svg>
          </span>
          Save
        </Button>
      </Row>
    </>
  );
}

export default Settings;
