import {
  Card,
  Page,
  Layout,
  TextContainer,
  Image,
  Stack,
  Link,
  Heading,
} from "@shopify/polaris";
import { useEffect, useState } from "react";
import Apptitle from "./Apptitle";
import { Container, Row, Col } from 'react-bootstrap';
import Settings from "./Settings";
import WidgetView from "./widgetView";
import { ProductsCard } from "./ProductsCard";
import WidgetButton from "./WidgetButton";

export function HomePage() {
  return (
    <>
    {/* <ProductsCard></ProductsCard> */}
        <Apptitle></Apptitle>
        <Container fluid>
          <Row>
            <Col sm={6}>
              <Settings></Settings>
            </Col>
            <Col sm={6}>
              {/* <WidgetButton/> */}
              <WidgetView></WidgetView>
            </Col>
          </Row>
        </Container>
    </>
  );
}
