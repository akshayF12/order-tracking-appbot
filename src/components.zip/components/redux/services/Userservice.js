import { Component } from 'react';
import Communication from './Communication';
import config from './config';
const UserService = {

    loadfaq(dispatch) {
        dispatch({
            type: 'LOAD_USERS',
            payload: null
        })
        Communication.getMethod(config.endPoints.users).then(users => {
                dispatch({
                    type: 'GET_USERS',
                    payload: users
                })
            })
            .catch(() => {
                dispatch({
                    type: 'ERROR_USERS',
                    payload: null
                })
            })
            .finally(() => {

            })
    },

    loadShop(dispatch,data) {
        dispatch({
            type: 'LOAD_SHOP',
            payload: data
        })
      
    },

    Component_hide_show(dispatch,data,settingsData) {
        if (data == 'reward') {
            dispatch({
                type: 'LOAD_REWARD',
                payload: settingsData
            }) 
        }

        if (data == 'track') {
            dispatch({
                type: 'LOAD_TRACK',
                payload: settingsData
            }) 
            
        }
       
      
    },

    loadprimarycolor(dispatch,data) {
        dispatch({
            type: 'LOAD_PRIMARY_COLOR',
            payload: data
        })
      
    },

    loadsecondarycolor(dispatch,data) {
        dispatch({
            type: 'LOAD_SECONDARY_COLOR',
            payload: data
        })
      
    },

    loadbackgroundcolor(dispatch,data) {
        dispatch({
            type: 'LOAD_BACKGROUND_COLOR',
            payload: data
        })
      
    },

    loadtertiaryColor(dispatch,data) {
        dispatch({
            type: 'LOAD_TERTIARY_COLOR',
            payload: data
        })
      
    },

    loadrewardcolor(dispatch,data) {
        dispatch({
            type: 'LOAD_REWARD_COLOR',
            payload: data
        })  
    },

    loadwidgetposition(dispatch,data) {
        dispatch({
            type: 'LOAD_WIDGET_POSITION',
            payload: data
        })  
    },

    loaddiscountbuttontext(dispatch,data) {
        dispatch({
            type: 'LOAD_DISCOUNT_BUTTON_TEXT',
            payload: data
        })  
    }, 

    loadwidgetbuttontext(dispatch,data) {
        dispatch({
            type: 'LOAD_WIDGET_BUTTON_TEXT',
            payload: data
        })  
    }, 
    
}
export default UserService;