const config = {
    baseUrl: 'https://wmt7gctnoc.execute-api.us-east-2.amazonaws.com/default/ShopifyAppProxy/',
    endPoints:{
        users: '?client_id=https://test-store-bob.myshopify.com&type=faq',
    }
};
export default config;