const initialState = {
    faqList : [],
    shop_data:[],
    reward: false,
    track: true,
    loading : true,
    error: false,
    primaryColor: '#145e54',
    secondaryColor: '#145e54',
    backgroundColor: '#ffffff',
    tertiaryColor: '#145e54',
    rewardpointColor: '#fae86e', 
    widgetposition: 'left',
    discountbuttontext: 'Get Code',
    widgetbutttontext: 'Reward'
  };

function faqReducer(state = initialState, action) {
  
    switch (action.type) {
        case 'LOAD_USERS':
            return { ...state, faqList:[], error: false, loading: true }
        case 'GET_USERS':
          return { ...state, faqList: action.payload, error: false, loading: false }
        case 'LOAD_REWARD':
          return { ...state, reward: action.payload , error: false, loading: false }
          case 'LOAD_TRACK':
            return { ...state, track: action.payload , error: false, loading: false }
        case 'LOAD_SHOP':
          return { ...state, shop_data: action.payload, error: false, loading: false }
        case 'LOAD_PRIMARY_COLOR':
          return { ...state, primaryColor: action.payload, error: false, loading: false }
        case 'LOAD_SECONDARY_COLOR':
          return { ...state, secondaryColor: action.payload, error: false, loading: false }
        case 'LOAD_BACKGROUND_COLOR':
          return { ...state, backgroundColor: action.payload, error: false, loading: false }
        case 'LOAD_TERTIARY_COLOR':
          return { ...state, tertiaryColor: action.payload, error: false, loading: false }
        case 'LOAD_REWARD_COLOR':
          return { ...state, rewardpointColor: action.payload, error: false, loading: false }   
        case 'LOAD_WIDGET_POSITION':
          return { ...state, widgetposition: action.payload, error: false, loading: false }
        case 'LOAD_DISCOUNT_BUTTON_TEXT':
          return { ...state, discountbuttontext: action.payload, error: false, loading: false }
        case 'LOAD_WIDGET_BUTTON_TEXT':
          return { ...state, widgetbutttontext: action.payload, error: false, loading: false }    
        case 'ERROR_USERS':
          return { ...state, faqList: [], error: true, loading: false }
          default:          
        return state;
    }
  };
  export default faqReducer;
  