import React,{useEffect,useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import UserService from './redux/services/Userservice';

function WidgetsFaq() {
    const [first, setfirst] = useState([])
    const [first1, setfirst1] = useState(0)
    const dispatch = useDispatch();
    const shopInfo = useSelector((state) => state.usersData);
    if (shopInfo.loading == false) {
      if (first1 == 0) {
        setfirst(shopInfo.faqList.faq);
        
        console.log(shopInfo);
        setfirst1(first1 + 1)
      }
   }
  useEffect(() => {
    UserService.loadfaq(dispatch);   
  }, [])
  
  return (
    <div>
        <div className="row action_wraper">
                <div className="faq_body">
                  <ul className="que_wraper">
                    {first != null ? first.map((faq, index) => (
                      <li key={index}>{faq.question}</li>
                    )):""}
                  </ul>
                </div>
              </div>

    </div>
  )
}

export default WidgetsFaq