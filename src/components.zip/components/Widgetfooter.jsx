import React,{useEffect,useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import UserService from './redux/services/Userservice';

function Widgetfooter() {
    const dispatch = useDispatch();
    const shopInfo = useSelector((state) => state.usersData);
   
    
 const onrewardbuttonclick = () => { 
     if (shopInfo.track == true) {
        const reward = 'reward';
        const track = 'track'
        const rewardvalue = true;
        const trackvalue = false;
        UserService.Component_hide_show(dispatch,reward,rewardvalue);
        UserService.Component_hide_show(dispatch,track,trackvalue); 
     }else{
        const data = 'reward';
        const value = true;
        UserService.Component_hide_show(dispatch,data,value);  
     }
    

};

const ontrackbuttonclick = () => { 

    if (shopInfo.reward == true) {
        const reward = 'reward';
        const track = 'track'
        const rewardvalue = false;
        const trackvalue = true;
        UserService.Component_hide_show(dispatch,reward,rewardvalue);
        UserService.Component_hide_show(dispatch,track,trackvalue); 
     }else{
        const data = 'track';
        const value = true;
        UserService.Component_hide_show(dispatch,data,value);  
     }

};

  return (
    <>
        <div className="text-center w-100 wigets_footer d-flex">
            <div className="footer_btn_wraper d-flex" style={{backgroundColor: shopInfo.tertiaryColor}}>
                <button className="footer_btn position-relative" id="help"><img
                        src="https://eee9-122-170-106-103.ngrok.io/view/interrogation.png" alt=""/>
                    <div className="arrow-up"></div>
                </button>
        
                <button className="footer_btn position-relative" id="whatapp"><img
                        src="https://eee9-122-170-106-103.ngrok.io/view/whatsapp.png" alt=""/>
                    <div className="arrow-up"></div>
                </button>
                <button className="footer_btn position-relative" id="reward" onClick={onrewardbuttonclick}><img
                        src="https://eee9-122-170-106-103.ngrok.io/view/gift.png" alt=""/>
                    <div className="arrow-up"></div>
                </button>
                <button className="footer_btn position-relative" id="track" onClick={ontrackbuttonclick}><img
                        src="https://eee9-122-170-106-103.ngrok.io/view/truck-moving.png" alt=""/>
                    <div className="arrow-up"></div>
                </button>
            </div>
        
        </div>
    </>
  )
}

export default Widgetfooter