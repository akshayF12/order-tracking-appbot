import React from "react";

function TruckScg(props) {
  return (
    <div>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        id="Layer_1"
        dataName="Layer 1"
        viewBox="0 0 24 24"
        width="25"
        height="25"
      >
        <path style={{ fill: props.iconcolor }} d="M24,12.649a5,5,0,0,0-.256-1.581L22.405,7.051A3,3,0,0,0,19.559,5H17V4a3,3,0,0,0-3-3H3A3,3,0,0,0,0,4V19.5a3.517,3.517,0,0,0,6,2.447A3.517,3.517,0,0,0,12,19.5V19h3v.5a3.5,3.5,0,0,0,7,0V19h2ZM19.559,7a1,1,0,0,1,.948.684L21.613,11H17V7ZM2,4A1,1,0,0,1,3,3H14a1,1,0,0,1,1,1V17H2ZM3.5,21A1.5,1.5,0,0,1,2,19.5V19H5v.5A1.5,1.5,0,0,1,3.5,21ZM10,19.5a1.5,1.5,0,0,1-3,0V19h3Zm10,0a1.5,1.5,0,0,1-3,0V19h3ZM17,17V13h5v4Z" />
      </svg>
    </div>
  );
}

export default TruckScg;
