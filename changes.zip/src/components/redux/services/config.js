const config = {
  baseUrl:
    "https://wmt7gctnoc.execute-api.us-east-2.amazonaws.com/default/ShopifyAppProxy/",
  endPoints: {
    settings: "?type=shopify_widget_details&client_id=",
  },
};
export default config;
